# discord-bot-spammer
Create multiple bots in your developer portal

# Showcases
- [Youtube Video](https://youtu.be/o_yrXRSEL3M)
- [GIF Proof](https://github.com/airlone/discord-bot-spammer/blob/main/images/proof.gif)

# Features
> - [x] Create multiple bots
> - [x] Create bots with different names
> - [x] Ratelimit handle
> - [x] Fast and Easy to use
> - [ ] Create with avatars and bio
> - [ ] Automaticly join a server


# Proof
> ![](https://github.com/airlone/discord-bot-spammer/blob/main/images/proof.gif)

# Help
- [Discord Server](https://discord.gg/9gzWYNrR)
- [Report a issue](https://github.com/airlone/discord-bot-spammer/issues/new)
- [Add me](https://discordapp.com/users/1003019817047044139)


# Simple-Discord-WebHook-Spammer
If you're not using the exe file in releases you will need to install dhooks using pip

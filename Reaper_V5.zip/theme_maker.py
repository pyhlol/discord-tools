import os
import json
import random
from colorama import Fore, init

init(autoreset=True)

def colorthing():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

def consolething(x, y):
    os.system(f"mode con: cols={y} lines={x}")

def generate_gradient(start, end, steps):
    colorthing = [
        (end[i] - start[i]) / steps for i in range(3)
    ]

    gradient = [
        tuple(
            int(start[i] + j * colorthing[i])
            for i in range(3)
        )
        for j in range(steps + 1)
    ]

    return gradient

def print_gradient(thing, gradient):
    for i, line in enumerate(thing):
        if i < len(gradient):
            color = gradient[i]
            rgb_values = f"{color[0]:02X}{color[1]:02X}{color[2]:02X}"
            print(f"\033[38;2;{color[0]};{color[1]};{color[2]}m{line}  ")
        else:
            print(line)

def save(name, start, end):
    theme = {
        "name": name,
        "start": f"{start[0]}, {start[1]}, {start[2]}",
        "end": f"{end[0]}, {end[1]}, {end[2]}"
    }

    if os.path.exists("data/themes.json"):
        with open("data/themes.json", "r") as themes_file:
            existingthings = json.load(themes_file)
    else:
        existingthings = []

    existingthings.append(theme)

    with open("data/themes.json", "w") as themes_file:
        json.dump(existingthings, themes_file, indent=4)

def main():
    ascii_art = """
    ╔══════════════════════════════╗                                     ╦═╗╔═╗╔═╗╔═╗╔═╗╦═╗                                     ╔══════════════════════════════╗
    ║        gg/cordreapers        ║                                     ╠╦╝║╣ ╠═╣╠═╝║╣ ╠╦╝                                     ║         Version: 4.2         ║
    ╚══════════════════════════════╝ [Connected]                         ╩╚═╚═╝╩ ╩╩  ╚═╝╩╚═                      [Account: Dev] ╚══════════════════════════════╝
    ╔═══════════════════════════════╦═══════════════════════════════╦══════════════════════════════╦═════════════════════════════╦═════════════════════════════╗
    ║ (01) Create Channels          ║ (02) Delete Channels          ║ (03) Lock Channels           ║ (04) Unlock Channels        ║ (05) Rename Channels        ║
    ╠═══════════════════════════════╬═══════════════════════════════╬══════════════════════════════╬═════════════════════════════╬═════════════════════════════╣
    ║ (06) Spam All Channels        ║ (07) Spam [Bypass]            ║ (08) Ban Members             ║ (09) Kick Members           ║ (10) Prune Members          ║
    ╠═══════════════════════════════╬═══════════════════════════════╬══════════════════════════════╬═════════════════════════════╬═════════════════════════════╣
    ║ (11) Create Roles             ║ (12) Delete Roles             ║ (13) Fetch All Roles         ║ (14) Grant Role             ║ (15) Delete Emojis          ║
    ╠═══════════════════════════════╬═══════════════════════════════╬══════════════════════════════╬═════════════════════════════╬═════════════════════════════╣
    ║ (16) Grant Admin              ║ (17) Grant Everyone Admin     ║ (18) Change Server Name      ║ (19) Guild Info             ║ (20) Scrape Servers         ║
    ╠═══════════════════════════════╬═══════════════════════════════╬══════════════════════════════╬═════════════════════════════╬═════════════════════════════╣
    ║ (21) Change Guild             ║ (22) Leave Guild              ║ (23) Leave All Guilds        ║ (24) Full Nuke              ║ (25) Create Emojis          ║
    ╠═══════════════════════════════╬═══════════════════════════════╬══════════════════════════════╬═════════════════════════════╬═════════════════════════════╣
    ║ (26) Mass DM                  ║ (27) Mass Nick                ║ (28) Update Info             ║ (29) Featured Members       ║ (69) gg/cordreapers         ║
    ╚═══════════════════════════════╩═══════════════════════════════╩══════════════════════════════╩═════════════════════════════╩═════════════════════════════╝
    ╔════════════════════════════════════════╗                                                                        ╔════════════════════════════════════════╗
    ║ Bot -                    xxxxxxxxxx    ║|-----------------------[Reaper, Fastest On Cord]----------------------|║    xxxxxxxxxx                - Guild   ║
    ╚════════════════════════════════════════╝                                                                        ╚════════════════════════════════════════╝
    """

    while True:
        consolething(40, 200)
        steps = len(ascii_art.split("\n")) - 1  
        start_color = colorthing()
        end_color = colorthing()
        gradient = generate_gradient(start_color, end_color, steps)

        print("\n Generated:")
        print_gradient(ascii_art.split("\n"), gradient)

        save_choice = input("Save? [Y to save or press enter to generate a new gradient]    >").lower()

        if save_choice == 'y':
            filename = input("Enter a name for the theme: ")
            save(filename, start_color, end_color)
            print("Saved")
            input("Press enter to make more")
        os.system('cls')

if __name__ == "__main__":
    main()
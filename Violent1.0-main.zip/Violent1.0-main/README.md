# Violent1.0 (OUTDATED)
Vioent1.0 is a powerful UNDETECTED remote acces tool whit a lot features(troll features are included too).
Violent1.0 uses a discord bot to communicate with the attacker and can bypass the firewall with this.
And before someone asks, I am not going to release the loader.

i am not responsible for any damages. Use at your own risk.
!!!for educational purposes only!!!

![MOSHED-2022-2-15-17-43-2](https://user-images.githubusercontent.com/102999825/211176071-8a9022fc-ce6a-4543-ae5d-87108fa9593c.gif)

![Screenshot 2022-05-10 220929](https://user-images.githubusercontent.com/102999825/167713592-a6355a3d-59a9-4713-a635-c368b0529ee9.png)

```
COMMANDS: 
[GENERAL] 
.get                                     lists online clients 
.target {id}                             selects target 
.drop {id}                               unselects target 
.targetall                               selects every client 
.dropall                                 unselects every client 
				
[SPECIFIC] 
.getinfo                                 gets info about the slected target 
.screenshot                              makes screenshot 
.speak {text}                            the target hears a voice on his pc 
.processes                               lists processes 
.terminate {name}                        kills process 
.rotatescreen {screen} {orientations}    rotates screen (DEGREES_CW_0, DEGREES_CW_90, DEGREES_CW_180,  DEGREES_CW_270) 
.unrotatescreen                          unrotates all screens 
.volume {volume}                         sets audio volume 
.screencount                             counts monitors 
.download {link} {path}                  download file 
.execute {path}               		 executes program 
.hidefile {path}                         hides file 
.showfile {path}                         shows file 
.smallupload {path}                      only usefull for sth like a txt file (8mb) 
.bigupload {path}                        big boy upload(20gb) 
.tree {typeFilter} {wordFilter} {disk}   gets evry path from drive 
.sendtree                                stops tree and sends file 
.getdrives                               lists all drives 
.deletefile {path}                       deletes file 
.filesize {path}                         gets file size in bytes 
.panic                                   stops virus but it will run again after restart 
.spam {amount}                           spams cmd windows 
.wallpaper {link} {type}                 changes the wallpaper 
.recordmic {milliseconds}                records microphone 
.gettoken                                grabs discord token 
.playaudio {link} {type}                 plays audio file 
.amiadmin				 show if you have admin privileges
.tryescalate				 uses a windows exploit to gain admin privileges
.message {text}				 shows a messagebox
.startstream				 sends screenshot every second
.stopstream				 stops streaming
.startkeylogger				 starts keylogger
.stopkeylogger				 stops keylogger
.bsod					 bluescreens pc (requires admin priveleges)
.blockinput				 blocks m&k input (requires admin priveleges)
.unblockinput				 unblocks m&k input (requires admin priveleges)
.crit					 user can't terminate the process without crshing the pc (requires admin priveleges)
.uncrit					 uncrits process (requires admin priveleges)
.troll					 troll + bsod (requires admin priveleges)
.encrdir {path} {typeFilter}             encrypts directory (requires admin priveleges)
.decrdir {path} 	                 decrypts directory (requires admin priveleges)
.mbrkiller			         overwrites mbr (completely destroys windows) (requires admin priveleges)
.disabletaskmgr				 disables task manager
.enabletaskmgr				 enables task manager
				
[SYNTAX] 
Text:                                    '_' -> ' ' 
Path:                                    '*' -> ' ' 
Filter:                                  '#' -> ''
```
